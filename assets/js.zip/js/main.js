document.addEventListener('DOMContentLoaded', function() {
    // Preloader
    const preloader = document.getElementById('preloader');
    if (preloader) {
      window.addEventListener('load', function() {
        setTimeout(function() {
          preloader.style.opacity = '0';
          setTimeout(function() {
            preloader.style.display = 'none';
          }, 500);
        }, 1000);
      });
    }
    
  
    // Matrix Rain Effect for Preloader
    function createMatrixRain() {
      const canvas = document.createElement('canvas');
      canvas.id = 'matrix-rain';
      canvas.style.position = 'absolute';
      canvas.style.top = '0';
      canvas.style.left = '0';
      canvas.style.width = '100%';
      canvas.style.height = '100%';
      canvas.style.zIndex = '1';
      preloader.appendChild(canvas);
  
      const ctx = canvas.getContext('2d');
      canvas.width = preloader.offsetWidth;
      canvas.height = preloader.offsetHeight;
  
      const katakana = 'アァカサタナハマヤャラワガザダバパイィキシチニヒミリヰギジヂビピウゥクスツヌフムユュルグズブヅプエェケセテネヘメレヱゲゼデベペオォコソトノホモヨョロヲゴゾドボポヴッン';
      const latin = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
      const nums = '0123456789';
      const alphabet = katakana + latin + nums;
  
      const fontSize = 16;
      const columns = canvas.width / fontSize;
      const rainDrops = [];
  
      for (let x = 0; x < columns; x++) {
        rainDrops[x] = 1;
      }
  
      const draw = () => {
        ctx.fillStyle = 'rgba(16, 24, 32, 0.05)';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        
        ctx.fillStyle = '#FEE715';
        ctx.font = fontSize + 'px monospace';
  
        for (let i = 0; i < rainDrops.length; i++) {
          const text = alphabet.charAt(Math.floor(Math.random() * alphabet.length));
          ctx.fillText(text, i * fontSize, rainDrops[i] * fontSize);
          
          if (rainDrops[i] * fontSize > canvas.height && Math.random() > 0.975) {
            rainDrops[i] = 0;
          }
          rainDrops[i]++;
        }
      };
  
      const interval = setInterval(draw, 30);
      
      // Cleanup when preloader is removed
      preloader.addEventListener('transitionend', function() {
        clearInterval(interval);
        canvas.remove();
      });
    }
  
    if (document.querySelector('.matrix-rain')) {
      createMatrixRain();
    }
  
    // Custom Cursor
    const cursor = document.querySelector('.cursor');
    const cursorFollower = document.querySelector('.cursor-follower');
    
    if (cursor && cursorFollower) {
      document.addEventListener('mousemove', (e) => {
        cursor.style.left = e.clientX + 'px';
        cursor.style.top = e.clientY + 'px';
        
        setTimeout(() => {
          cursorFollower.style.left = e.clientX + 'px';
          cursorFollower.style.top = e.clientY + 'px';
        }, 100);
      });
  
      // Cursor hover effects
      const hoverElements = document.querySelectorAll('a, button, .portfolio-item, .icon-box, input, textarea');
      hoverElements.forEach(el => {
        el.addEventListener('mouseenter', () => {
          cursor.style.transform = 'scale(2)';
          cursor.style.backgroundColor = 'transparent';
          cursor.style.border = '1px solid #FEE715';
          cursorFollower.style.transform = 'scale(0.5)';
          cursorFollower.style.backgroundColor = 'rgba(254, 231, 21, 0.5)';
        });
        
        el.addEventListener('mouseleave', () => {
          cursor.style.transform = 'scale(1)';
          cursor.style.backgroundColor = '#FEE715';
          cursor.style.border = 'none';
          cursorFollower.style.transform = 'scale(1)';
          cursorFollower.style.backgroundColor = 'transparent';
        });
      });
    }
  
    // Particles.js Background
    if (document.getElementById('particles-js')) {
      particlesJS('particles-js', {
        "particles": {
          "number": {
            "value": 80,
            "density": {
              "enable": true,
              "value_area": 800
            }
          },
          "color": {
            "value": "#FEE715"
          },
          "shape": {
            "type": "circle",
            "stroke": {
              "width": 0,
              "color": "#000000"
            },
            "polygon": {
              "nb_sides": 5
            }
          },
          "opacity": {
            "value": 0.5,
            "random": true,
            "anim": {
              "enable": true,
              "speed": 1,
              "opacity_min": 0.1,
              "sync": false
            }
          },
          "size": {
            "value": 3,
            "random": true,
            "anim": {
              "enable": true,
              "speed": 2,
              "size_min": 0.1,
              "sync": false
            }
          },
          "line_linked": {
            "enable": true,
            "distance": 150,
            "color": "#FEE715",
            "opacity": 0.3,
            "width": 1
          },
          "move": {
            "enable": true,
            "speed": 1,
            "direction": "none",
            "random": true,
            "straight": false,
            "out_mode": "out",
            "bounce": false,
            "attract": {
              "enable": true,
              "rotateX": 600,
              "rotateY": 1200
            }
          }
        },
        "interactivity": {
          "detect_on": "canvas",
          "events": {
            "onhover": {
              "enable": true,
              "mode": "grab"
            },
            "onclick": {
              "enable": true,
              "mode": "push"
            },
            "resize": true
          },
          "modes": {
            "grab": {
              "distance": 140,
              "line_linked": {
                "opacity": 0.8
              }
            },
            "push": {
              "particles_nb": 4
            }
          }
        },
        "retina_detect": true
      });
    }
  
    // Typed.js Animation for Hero Section
    if (document.querySelector('.typed')) {
      const typed = new Typed('.typed', {
        strings: ['Designer', 'Developer', 'Creator', 'Innovator'],
        typeSpeed: 100,
        backSpeed: 60,
        backDelay: 2000,
        loop: true,
        showCursor: true,
        cursorChar: '|',
        smartBackspace: true
      });
    }
  
    // Smooth Scrolling for Navigation
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', function(e) {
        e.preventDefault();
        
        const targetId = this.getAttribute('href');
        if (targetId === '#') return;
        
        const targetElement = document.querySelector(targetId);
        if (targetElement) {
          window.scrollTo({
            top: targetElement.offsetTop - 70,
            behavior: 'smooth'
          });
        }
      });
    });
  
    // Header Scroll Effect
    const header = document.getElementById('header');
    if (header) {
      window.addEventListener('scroll', function() {
        if (window.scrollY > 100) {
          header.classList.add('header-scrolled');
        } else {
          header.classList.remove('header-scrolled');
        }
      });
    }
  
    // Mobile Navigation Toggle
    const mobileNavToggle = document.querySelector('.mobile-nav-toggle');
    const navbar = document.getElementById('navbar');
    if (mobileNavToggle && navbar) {
      mobileNavToggle.addEventListener('click', function() {
        navbar.classList.toggle('navbar-mobile');
        this.classList.toggle('bx-x');
      });
    }
  
    // Portfolio Filtering
    const portfolioFilters = document.querySelectorAll('#portfolio-flters li');
    const portfolioItems = document.querySelectorAll('.portfolio-item');
    
    if (portfolioFilters.length && portfolioItems.length) {
      portfolioFilters.forEach(filter => {
        filter.addEventListener('click', function() {
          // Remove active class from all filters
          portfolioFilters.forEach(f => f.classList.remove('filter-active'));
          
          // Add active class to clicked filter
          this.classList.add('filter-active');
          
          // Get filter value
          const filterValue = this.getAttribute('data-filter');
          
          // Show/hide portfolio items
          portfolioItems.forEach(item => {
            if (filterValue === '*' || item.classList.contains(filterValue.substring(1))) {
              item.style.display = 'block';
              item.classList.add('animate__animated', 'animate__fadeIn');
            } else {
              item.style.display = 'none';
              item.classList.remove('animate__animated', 'animate__fadeIn');
            }
          });
          
          // Initialize Isotope after filtering
          initIsotope();
        });
      });
    }
  
    // Initialize Isotope for Portfolio
    function initIsotope() {
      const portfolioContainer = document.querySelector('.portfolio-container');
      if (portfolioContainer) {
        imagesLoaded(portfolioContainer, function() {
          const iso = new Isotope(portfolioContainer, {
            itemSelector: '.portfolio-item',
            layoutMode: 'fitRows',
            percentPosition: true,
            transitionDuration: '0.7s',
            hiddenStyle: {
              opacity: 0,
              transform: 'scale(0.001)'
            },
            visibleStyle: {
              opacity: 1,
              transform: 'scale(1)'
            }
          });
        });
      }
    }
  
    // Initialize on load
    initIsotope();
  
    // Testimonials Slider
    const testimonialsSlider = document.querySelector('.testimonials-slider');
    if (testimonialsSlider) {
      new Swiper(testimonialsSlider, {
        loop: true,
        autoplay: {
          delay: 5000,
          disableOnInteraction: false
        },
        slidesPerView: 1,
        spaceBetween: 30,
        pagination: {
          el: '.swiper-pagination',
          clickable: true,
          dynamicBullets: true
        },
        breakpoints: {
          992: {
            slidesPerView: 2
          }
        }
      });
    }
  
    // Back to Top Button
    const backToTopButton = document.querySelector('.back-to-top');
    if (backToTopButton) {
      window.addEventListener('scroll', function() {
        if (window.scrollY > 300) {
          backToTopButton.classList.add('active');
        } else {
          backToTopButton.classList.remove('active');
        }
      });
      
      backToTopButton.addEventListener('click', function(e) {
        e.preventDefault();
        window.scrollTo({
          top: 0,
          behavior: 'smooth'
        });
      });
    }
  
    // Animation on Scroll
    AOS.init({
      duration: 800,
      easing: 'ease-in-out',
      once: true,
      mirror: false
    });
  
    // Skills Animation
    const skillsContent = document.querySelector('.skills-container');
    if (skillsContent) {
      window.addEventListener('scroll', function() {
        const skillsPosition = skillsContent.getBoundingClientRect().top;
        const screenPosition = window.innerHeight / 1.3;
        
        if (skillsPosition < screenPosition) {
          document.querySelectorAll('.progress-bar').forEach(bar => {
            const width = bar.getAttribute('aria-valuenow');
            bar.style.width = width + '%';
          });
        }
      });
    }
  
    // Form Submission
    const contactForm = document.querySelector('.php-email-form');
    if (contactForm) {
      contactForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        const formAction = this.getAttribute('action');
        const formMethod = this.getAttribute('method');
        
        const loading = this.querySelector('.loading');
        const errorMessage = this.querySelector('.error-message');
        const sentMessage = this.querySelector('.sent-message');
        
        loading.style.display = 'block';
        errorMessage.style.display = 'none';
        sentMessage.style.display = 'none';
        
        fetch(formAction, {
          method: formMethod,
          body: formData
        })
        .then(response => {
          if (response.ok) {
            return response.text();
          }
          throw new Error('Network response was not ok.');
        })
        .then(data => {
          loading.style.display = 'none';
          sentMessage.style.display = 'block';
          contactForm.reset();
          setTimeout(() => {
            sentMessage.style.display = 'none';
          }, 5000);
        })
        .catch(error => {
          loading.style.display = 'none';
          errorMessage.style.display = 'block';
          errorMessage.innerHTML = 'There was an error sending your message. Please try again later.';
          setTimeout(() => {
            errorMessage.style.display = 'none';
          }, 5000);
        });
      });
    }
  
    // 3D Holographic Effect for Avatar
    const holographicAvatar = document.querySelector('.holographic-avatar');
    if (holographicAvatar) {
      let mouseX = 0;
      let mouseY = 0;
      let frameX = 0;
      let frameY = 0;
      
      document.addEventListener('mousemove', (e) => {
        mouseX = (e.clientX / window.innerWidth) * 2 - 1;
        mouseY = -(e.clientY / window.innerHeight) * 2 + 1;
      });
      
      function animateAvatar() {
        frameX += (mouseX - frameX) * 0.05;
        frameY += (mouseY - frameY) * 0.05;
        
        if (holographicAvatar.firstChild) {
          holographicAvatar.firstChild.style.transform = `rotateY(${frameX * 15}deg) rotateX(${frameY * 15}deg)`;
        }
        
        requestAnimationFrame(animateAvatar);
      }
      
      animateAvatar();
    }
  
    // Scroll Down Indicator Animation
    const scrollDownIndicator = document.querySelector('.scroll-down');
    if (scrollDownIndicator) {
      function animateScrollDown() {
        const scroller = scrollDownIndicator.querySelector('.scroller');
        scroller.style.animation = 'scrollDown 2s infinite';
      }
      
      animateScrollDown();
      
      // Add keyframes dynamically
      const style = document.createElement('style');
      style.innerHTML = `
        @keyframes scrollDown {
          0% {
            transform: translateY(0);
            opacity: 1;
          }
          50% {
            transform: translateY(10px);
            opacity: 0.5;
          }
          100% {
            transform: translateY(0);
            opacity: 1;
          }
        }
      `;
      document.head.appendChild(style);
    }
  });



  document.addEventListener('DOMContentLoaded', function() {
    const container = document.getElementById('binary-rain');
    if (!container) return;
    
    // Create binary rain
    const cols = Math.floor(container.offsetWidth / 20);
    const rows = Math.floor(container.offsetHeight / 24);
    const chars = ['0', '1'];
    
    for (let i = 0; i < cols; i++) {
      const col = document.createElement('div');
      col.className = 'binary-column';
      col.style.left = `${i * 20}px`;
      
      const duration = 3 + Math.random() * 4;
      const delay = Math.random() * 5;
      col.style.animationDuration = `${duration}s`;
      col.style.animationDelay = `-${delay}s`;
      
      for (let j = 0; j < rows; j++) {
        const char = document.createElement('span');
        char.textContent = chars[Math.floor(Math.random() * chars.length)];
        char.style.opacity = Math.random() * 0.5 + 0.1;
        col.appendChild(char);
      }
      
      container.appendChild(col);
    }
    
    // Initialize Typed.js if exists
    if (document.querySelector('.typed')) {
      new Typed('.typed', {
        strings: ['Designer', 'Developer', 'Creator', 'Innovator'],
        typeSpeed: 100,
        backSpeed: 60,
        backDelay: 2000,
        loop: true,
        showCursor: true,
        cursorChar: '|',
        smartBackspace: true
      });
    }
    
    // Make binary columns react to mouse
    container.addEventListener('mousemove', (e) => {
      const binaryCols = document.querySelectorAll('.binary-column');
      const rect = container.getBoundingClientRect();
      const x = e.clientX - rect.left;
      
      binaryCols.forEach(col => {
        const colX = parseInt(col.style.left);
        const distance = Math.abs(x - colX);
        if (distance < 50) {
          const intensity = 1 - (distance / 50);
          col.style.opacity = intensity;
          col.style.animationDuration = `${2 + intensity}s`;
          col.style.color = `rgba(254, 231, 21, ${0.2 + intensity * 0.5})`;
        }
      });
    });
  });